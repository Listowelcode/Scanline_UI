import uuid


jobs = {}


def create_job(youtube_url: str):

    job_id = str(uuid.uuid4())

    jobs[job_id] = {
        "status": "processing",
        "progress": 0,
        "youtube_url": youtube_url,
        "message": "Scan started"
    }

    return job_id


def get_job(job_id: str):

    return jobs.get(job_id)


def update_job(job_id: str, data: dict):

    if job_id in jobs:
        jobs[job_id].update(data)